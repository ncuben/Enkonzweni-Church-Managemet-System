eNkonzweni Church Management System
******************************************************************
eNkonzweni Church Management System is a web based system that is responsive and 
runs in all screens and gives a good resolution display.Its a System that aims
to bridge the gap that the churches are facing in administration.Its a robust system 
taht has the ability for intergration with erps that focus on other aspects 
of administration as in other business units.It is a Church Business automation
engine.It can be in stalled on all platforms that are available in today's world.To mention a few, 
Linux Ubuntu server, Windows Server, MacOS, Android.


It gives a digital feel of the church.Reports are just a click away.It gives out profiling
for the churches.Its scalable to greater heights with more room for continous development.

This systems runs on Mysql database.
Remember to keep the Sabbath Day Holy;
*******************************************************************
Developer I: 	Ncube Ntokozo
Cell:							+263712948663 OR +263774002534
Developer Email:				ncuben@solusi.ac.zw

Developer II: Fortunate Chiratidzo Mandizwidza
Cell:                           +263773799023
Developer Email: 				fcmurenzvi@gmail.com

