 <div id="sidebar-main" class="sidebar sidebar-default">
    <div class="sidebar-content">
        <ul class="navigation">
            <li class="navigation-header">
                <span>Main</span>
                <i class="icon-menu"></i>
            </li>
<li>
                <a href="../index.php"><i class="fa fa-home"></i> <span>Home</span></a>
            </li>

            <li>
                <a href="../login.php"><i class="fa fa-home"></i> <span>Administrator Login</span></a>
            </li>

             <li>
                <a href="login.php"><i class="fa fa-pencil"></i> <span>Church Member Login</span></a>
                
            </li>

            
        </ul>
    </div>
</div>
