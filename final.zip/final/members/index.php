<?php include ("inc/header.php");
		include ("inc/topnav.php");
		include("inc/member-sidebar.php");
		$pagetitle ="eNkonzweni Church Management System";
		?>      <!-- PAGE CONTENT -->
           <div class="content-wrapper">
                <div class="content">
                    <div class="row">
                        <div class="col-lg-12">
                            <h4 class="card-title">Members Home Page</h4>
                            <p>
                            <div class="row-fluid">
					<div class="span12">
						<div class="alert alert-info">
							 <strong>Welcome to eNkonzweni Church Management System Member's Portal.Navigate using the Menu Section bar.Enjoy!!</strong>
							<a href="#" data-dismiss="alert" class="close">×</a></div>
                        </div>
                                <div class="row-fluid">
					<div class="span12">
						<div class="alert alert-danger">
							 <strong>Verse of the Day!</strong>: But blessed are your eyes, for they see: and your ears, for they hear.- Matt: 13:16
							<a href="#" data-dismiss="alert" class="close">×</a>
						</div>
                        </div>
                    </div>